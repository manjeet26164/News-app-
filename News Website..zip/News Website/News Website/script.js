const API_KEY = "0d3c879e71b0472cbd862abc6eb4c6be";
const url = "https://newsapi.org/v2/everything?q=";

// Function to show loader
function showLoader() {
    const loader = document.getElementById('loader');
    loader.classList.add('active');
}

// Function to hide loader
function hideLoader() {
    const loader = document.getElementById('loader');
    loader.classList.remove('active');
}

window.addEventListener("load", () => fetchNews("Technology"));

async function fetchNews(query) {
    try {
        // Show loader before fetching
        showLoader();

        const res = await fetch(`${url}${query}&apiKey=${API_KEY}`);
        
        // Add a small delay to make loader visible (optional)
        await new Promise(resolve => setTimeout(resolve, 500));

        const data = await res.json();
        bindData(data.articles);
    } catch (error) {
        console.error("Error fetching news:", error);
        // Optionally show an error message to the user
        alert("Failed to fetch news. Please try again.");
    } finally {
        // Hide loader after fetching (whether successful or not)
        hideLoader();
    }
}

function bindData(articles) {
    const cardsContainer = document.getElementById("cardscontainer");
    const newsCardTemplate = document.getElementById("template-news-card");

    cardsContainer.innerHTML = "";

    articles.forEach((article) => {
        if (!article.urlToImage) return;

        const cardClone = newsCardTemplate.content.cloneNode(true);
        fillDataInCard(cardClone, article);
        cardsContainer.appendChild(cardClone);
    });
}

function fillDataInCard(cardClone, article) {
    const newsImg = cardClone.querySelector("#news-img");
    const newsTitle = cardClone.querySelector("#news-title");
    const newsSource = cardClone.querySelector("#news-source");
    const newsDesc = cardClone.querySelector("#news-desc");

    newsImg.src = article.urlToImage;
    newsTitle.innerHTML = `${article.title.slice(0, 60)}...`;
    newsDesc.innerHTML = `${article.description.slice(0, 150)}...`;

    const date = new Date(article.publishedAt).toLocaleString("en-US", { timeZone: "Asia/Jakarta" });

    newsSource.innerHTML = `${article.source.name} · ${date}`;

    cardClone.firstElementChild.addEventListener("click", () => {
        window.open(article.url, "_blank");
    });
}

let curSelectedNav = null;
function onNavItemClick(id) {
    fetchNews(id);
    const navItem = document.getElementById(id);
    curSelectedNav?.classList.remove("active");
    curSelectedNav = navItem;
    curSelectedNav.classList.add("active");
}

const searchButton = document.getElementById("search-button");
const searchText = document.getElementById("search-text");

// Function to perform search
function performSearch() {
    const query = searchText.value;
    if (!query) return;
    fetchNews(query);
    curSelectedNav?.classList.remove("active");
    curSelectedNav = null;
}

// Event listener for search button click
searchButton.addEventListener("click", performSearch);

// Event listener for enter key press on search input
searchText.addEventListener("keypress", (e) => {
    // Check if the pressed key is Enter (key code 13)
    if (e.key === 'Enter') {
        performSearch();
    }
});